import React from 'react';
import { useProductStore } from './store/productStore';
import { ProductForm } from './components/ProductForm';
import { ProductList } from './components/ProductList';
import './App.css';

function App() {
  const [selectedProductId, setSelectedProductId] = React.useState<number | null>(null);
  
  const selectProduct = useProductStore((state) => state.selectProduct);
  const products = useProductStore((state) => state.products);

  const handleFormSuccess = () => {
    setSelectedProductId(null);
  };

  const handleEditProduct = (id: number) => {
    const product = products.find((p) => p.id === id);
    if (product) {
      selectProduct(product);
      setSelectedProductId(id);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-blue-600 text-white p-4 shadow">
        <h1 className="text-3xl font-bold">Product Management</h1>
        <p className="text-blue-100">React CRUD Application</p>
      </nav>
      
      <div className="container mx-auto py-8 px-4">
        <ProductForm productId={selectedProductId} onSuccess={handleFormSuccess} />
        <div className="bg-white p-6 rounded-lg shadow">
          <h2 className="text-2xl font-bold mb-4">Products</h2>
          <ProductList onEdit={handleEditProduct} />
        </div>
      </div>
    </div>
  );
}

export default App;
