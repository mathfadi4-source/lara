const API_URL = 'http://localhost:8000/api/v1';

export interface Product {
  id: number;
  name: string;
  description: string | null;
  price: number;
  quantity: number;
  created_at: string;
  updated_at: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data?: T;
}

export const productService = {
  getAll: async (): Promise<Product[]> => {
    const response = await fetch(`${API_URL}/products`);
    const data: ApiResponse<Product[]> = await response.json();
    if (!data.success) throw new Error(data.message);
    return data.data || [];
  },

  getById: async (id: number): Promise<Product> => {
    const response = await fetch(`${API_URL}/products/${id}`);
    const data: ApiResponse<Product> = await response.json();
    if (!data.success) throw new Error(data.message);
    return data.data!;
  },

  create: async (product: Omit<Product, 'id' | 'created_at' | 'updated_at'>): Promise<Product> => {
    const response = await fetch(`${API_URL}/products`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    const data: ApiResponse<Product> = await response.json();
    if (!data.success) throw new Error(data.message);
    return data.data!;
  },

  update: async (id: number, product: Partial<Omit<Product, 'id' | 'created_at' | 'updated_at'>>): Promise<Product> => {
    const response = await fetch(`${API_URL}/products/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(product),
    });
    const data: ApiResponse<Product> = await response.json();
    if (!data.success) throw new Error(data.message);
    return data.data!;
  },

  delete: async (id: number): Promise<void> => {
    const response = await fetch(`${API_URL}/products/${id}`, { method: 'DELETE' });
    const data: ApiResponse<void> = await response.json();
    if (!data.success) throw new Error(data.message);
  },
};
