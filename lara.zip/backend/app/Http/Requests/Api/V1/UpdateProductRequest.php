<?php

namespace App\Http\Requests\Api\V1;

use Illuminate\Foundation\Http\FormRequest;

class UpdateProductRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'price' => 'sometimes|numeric|min:0',
            'quantity' => 'sometimes|integer|min:0',
        ];
    }

    public function messages()
    {
        return [
            'name.string' => 'Product name must be a string',
            'name.max' => 'Product name cannot exceed 255 characters',
            'price.numeric' => 'Product price must be a number',
            'price.min' => 'Product price cannot be negative',
            'quantity.integer' => 'Product quantity must be an integer',
            'quantity.min' => 'Product quantity cannot be negative',
        ];
    }
}
