import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, CommonModule],
  template: `
    <div class="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <!-- Navigation Bar -->
      <nav class="backdrop-blur-md bg-black/30 border-b border-purple-500/20 sticky top-0 z-50">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div class="flex justify-between items-center h-16">
            <div class="flex items-center space-x-3">
              <div class="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-600 rounded-lg flex items-center justify-center">
                <span class="text-white font-bold text-lg">P</span>
              </div>
              <h1 class="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">ProductHub</h1>
            </div>
            <div class="hidden md:flex space-x-8">
              <a routerLink="/products" class="text-gray-300 hover:text-white transition-colors duration-200">Products</a>
              <a href="#features" class="text-gray-300 hover:text-white transition-colors duration-200">Features</a>
              <a href="#about" class="text-gray-300 hover:text-white transition-colors duration-200">About</a>
            </div>
          </div>
        </div>
      </nav>

      <!-- Hero Section -->
      <div class="relative overflow-hidden">
        <div class="absolute inset-0 bg-gradient-to-b from-purple-500/10 via-transparent to-transparent"></div>
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative">
          <div class="text-center mb-12">
            <h2 class="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Manage Your Products
              <span class="block bg-gradient-to-r from-purple-400 via-pink-400 to-purple-400 bg-clip-text text-transparent">With Ease</span>
            </h2>
            <p class="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
              A modern, full-stack CRUD application built with Laravel, React, and Angular. Experience seamless product management across multiple frameworks.
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
              <a routerLink="/products" class="px-8 py-3 bg-gradient-to-r from-purple-500 to-pink-600 text-white rounded-lg font-semibold hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-200 transform hover:scale-105">
                Get Started
              </a>
              <button class="px-8 py-3 border border-purple-500/50 text-white rounded-lg font-semibold hover:bg-purple-500/10 transition-colors duration-200">
                Learn More
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Features Section -->
      <div id="features" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h3 class="text-4xl font-bold text-white text-center mb-12">Powerful Features</h3>
        <div class="grid md:grid-cols-3 gap-8">
          <!-- Feature 1 -->
          <div class="group relative">
            <div class="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div class="relative bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-8 hover:border-purple-500/50 transition-colors duration-200">
              <div class="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-600 rounded-lg flex items-center justify-center mb-4">
                <span class="text-white text-xl">⚡</span>
              </div>
              <h4 class="text-xl font-bold text-white mb-3">Lightning Fast</h4>
              <p class="text-gray-400">Optimized performance with lazy loading, state management, and efficient caching strategies.</p>
            </div>
          </div>

          <!-- Feature 2 -->
          <div class="group relative">
            <div class="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div class="relative bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-8 hover:border-purple-500/50 transition-colors duration-200">
              <div class="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-600 rounded-lg flex items-center justify-center mb-4">
                <span class="text-white text-xl">🔒</span>
              </div>
              <h4 class="text-xl font-bold text-white mb-3">Secure & Reliable</h4>
              <p class="text-gray-400">Enterprise-grade security with proper authentication, validation, and error handling.</p>
            </div>
          </div>

          <!-- Feature 3 -->
          <div class="group relative">
            <div class="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-pink-500/20 rounded-lg blur opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div class="relative bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-8 hover:border-purple-500/50 transition-colors duration-200">
              <div class="w-12 h-12 bg-gradient-to-br from-purple-400 to-pink-600 rounded-lg flex items-center justify-center mb-4">
                <span class="text-white text-xl">🎨</span>
              </div>
              <h4 class="text-xl font-bold text-white mb-3">Beautiful UI</h4>
              <p class="text-gray-400">Modern, responsive design that works seamlessly across all devices and screen sizes.</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Tech Stack Section -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <h3 class="text-4xl font-bold text-white text-center mb-12">Built With Modern Tech</h3>
        <div class="grid md:grid-cols-4 gap-6">
          <div class="bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-6 text-center hover:border-purple-500/50 transition-colors duration-200">
            <div class="text-4xl mb-3">🚀</div>
            <h4 class="text-white font-bold mb-2">Laravel 12</h4>
            <p class="text-gray-400 text-sm">Powerful backend API with SOLID principles</p>
          </div>
          <div class="bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-6 text-center hover:border-purple-500/50 transition-colors duration-200">
            <div class="text-4xl mb-3">⚛️</div>
            <h4 class="text-white font-bold mb-2">React 18</h4>
            <p class="text-gray-400 text-sm">Modern frontend with Zustand state management</p>
          </div>
          <div class="bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-6 text-center hover:border-purple-500/50 transition-colors duration-200">
            <div class="text-4xl mb-3">🅰️</div>
            <h4 class="text-white font-bold mb-2">Angular 17</h4>
            <p class="text-gray-400 text-sm">Advanced frontend with NgRx store</p>
          </div>
          <div class="bg-black/40 backdrop-blur border border-purple-500/20 rounded-lg p-6 text-center hover:border-purple-500/50 transition-colors duration-200">
            <div class="text-4xl mb-3">🎨</div>
            <h4 class="text-white font-bold mb-2">Tailwind CSS</h4>
            <p class="text-gray-400 text-sm">Utility-first CSS for responsive design</p>
          </div>
        </div>
      </div>

      <!-- Router Outlet -->
      <router-outlet></router-outlet>

      <!-- Footer -->
      <footer class="border-t border-purple-500/20 bg-black/40 backdrop-blur mt-20">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center">
          <p class="text-gray-400">© 2024 ProductHub. Built with ❤️ using modern technologies.</p>
        </div>
      </footer>
    </div>
  `,
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ProductHub';
}
