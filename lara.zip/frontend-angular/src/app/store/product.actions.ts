import { createAction, props } from '@ngrx/store';
import { Product } from '../services/product.service';

// Load Products
export const loadProducts = createAction(
  '[Product Page] Load Products'
);

export const loadProductsSuccess = createAction(
  '[Product API] Load Products Success',
  props<{ products: Product[] }>()
);

export const loadProductsFailure = createAction(
  '[Product API] Load Products Failure',
  props<{ error: string }>()
);

// Load Single Product
export const loadProduct = createAction(
  '[Product Details Page] Load Product',
  props<{ id: number }>()
);

export const loadProductSuccess = createAction(
  '[Product API] Load Product Success',
  props<{ product: Product }>()
);

export const loadProductFailure = createAction(
  '[Product API] Load Product Failure',
  props<{ error: string }>()
);

// Create Product
export const createProduct = createAction(
  '[Product Create Page] Create Product',
  props<{ product: Omit<Product, 'id' | 'created_at' | 'updated_at'> }>()
);

export const createProductSuccess = createAction(
  '[Product API] Create Product Success',
  props<{ product: Product }>()
);

export const createProductFailure = createAction(
  '[Product API] Create Product Failure',
  props<{ error: string }>()
);

// Update Product
export const updateProduct = createAction(
  '[Product Edit Page] Update Product',
  props<{ id: number; product: Partial<Omit<Product, 'id' | 'created_at' | 'updated_at'>> }>()
);

export const updateProductSuccess = createAction(
  '[Product API] Update Product Success',
  props<{ product: Product }>()
);

export const updateProductFailure = createAction(
  '[Product API] Update Product Failure',
  props<{ error: string }>()
);

// Delete Product
export const deleteProduct = createAction(
  '[Product Delete] Delete Product',
  props<{ id: number }>()
);

export const deleteProductSuccess = createAction(
  '[Product API] Delete Product Success',
  props<{ id: number }>()
);

export const deleteProductFailure = createAction(
  '[Product API] Delete Product Failure',
  props<{ error: string }>()
);

// Clear Selection
export const clearProductSelection = createAction(
  '[Product] Clear Selection'
);
