import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ProductState } from './product.reducer';

export const selectProductFeature = createFeatureSelector<ProductState>('products');

export const selectAllProducts = createSelector(
  selectProductFeature,
  (state: ProductState) => state.products
);

export const selectSelectedProduct = createSelector(
  selectProductFeature,
  (state: ProductState) => state.selectedProduct
);

export const selectLoadingState = createSelector(
  selectProductFeature,
  (state: ProductState) => state.loading
);

export const selectErrorState = createSelector(
  selectProductFeature,
  (state: ProductState) => state.error
);

export const selectProductById = (id: number) =>
  createSelector(
    selectAllProducts,
    (products) => products.find((p) => p.id === id) || null
  );

export const selectProductCount = createSelector(
  selectAllProducts,
  (products) => products.length
);

export const selectProductsWithLoading = createSelector(
  selectAllProducts,
  selectLoadingState,
  (products, loading) => ({ products, loading })
);
