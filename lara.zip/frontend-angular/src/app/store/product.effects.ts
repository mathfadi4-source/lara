import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, switchMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { ProductService } from '../services/product.service';
import * as ProductActions from './product.actions';

@Injectable()
export class ProductEffects {
  loadProducts$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductActions.loadProducts),
      switchMap(() =>
        this.productService.getAll().pipe(
          map((response) =>
            ProductActions.loadProductsSuccess({
              products: response.data || [],
            })
          ),
          catchError((error) =>
            of(
              ProductActions.loadProductsFailure({
                error: error.error?.message || 'Failed to load products',
              })
            )
          )
        )
      )
    )
  );

  loadProduct$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductActions.loadProduct),
      switchMap(({ id }) =>
        this.productService.getById(id).pipe(
          map((response) =>
            ProductActions.loadProductSuccess({
              product: response.data!,
            })
          ),
          catchError((error) =>
            of(
              ProductActions.loadProductFailure({
                error: error.error?.message || 'Failed to load product',
              })
            )
          )
        )
      )
    )
  );

  createProduct$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductActions.createProduct),
      switchMap(({ product }) =>
        this.productService.create(product).pipe(
          map((response) =>
            ProductActions.createProductSuccess({
              product: response.data!,
            })
          ),
          catchError((error) =>
            of(
              ProductActions.createProductFailure({
                error: error.error?.message || 'Failed to create product',
              })
            )
          )
        )
      )
    )
  );

  updateProduct$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductActions.updateProduct),
      switchMap(({ id, product }) =>
        this.productService.update(id, product).pipe(
          map((response) =>
            ProductActions.updateProductSuccess({
              product: response.data!,
            })
          ),
          catchError((error) =>
            of(
              ProductActions.updateProductFailure({
                error: error.error?.message || 'Failed to update product',
              })
            )
          )
        )
      )
    )
  );

  deleteProduct$ = createEffect(() =>
    this.actions$.pipe(
      ofType(ProductActions.deleteProduct),
      switchMap(({ id }) =>
        this.productService.delete(id).pipe(
          map(() =>
            ProductActions.deleteProductSuccess({
              id,
            })
          ),
          catchError((error) =>
            of(
              ProductActions.deleteProductFailure({
                error: error.error?.message || 'Failed to delete product',
              })
            )
          )
        )
      )
    )
  );

  constructor(
    private actions$: Actions,
    private productService: ProductService
  ) {}
}
