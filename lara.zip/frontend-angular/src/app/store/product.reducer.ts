import { createReducer, on } from '@ngrx/store';
import { Product } from '../services/product.service';
import * as ProductActions from './product.actions';

export interface ProductState {
  products: Product[];
  selectedProduct: Product | null;
  loading: boolean;
  error: string | null;
}

export const initialState: ProductState = {
  products: [],
  selectedProduct: null,
  loading: false,
  error: null,
};

export const productReducer = createReducer(
  initialState,
  
  // Load Products
  on(ProductActions.loadProducts, (state: ProductState) => ({
    ...state,
    loading: true,
    error: null,
  })),
  on(ProductActions.loadProductsSuccess, (state: ProductState, { products }: { products: Product[] }) => ({
    ...state,
    products,
    loading: false,
  })),
  on(ProductActions.loadProductsFailure, (state: ProductState, { error }: { error: string }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Load Single Product
  on(ProductActions.loadProduct, (state: ProductState) => ({
    ...state,
    loading: true,
    error: null,
  })),
  on(ProductActions.loadProductSuccess, (state: ProductState, { product }: { product: Product }) => ({
    ...state,
    selectedProduct: product,
    loading: false,
  })),
  on(ProductActions.loadProductFailure, (state: ProductState, { error }: { error: string }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Create Product
  on(ProductActions.createProduct, (state: ProductState) => ({
    ...state,
    loading: true,
    error: null,
  })),
  on(ProductActions.createProductSuccess, (state: ProductState, { product }: { product: Product }) => ({
    ...state,
    products: [...state.products, product],
    loading: false,
  })),
  on(ProductActions.createProductFailure, (state: ProductState, { error }: { error: string }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Update Product
  on(ProductActions.updateProduct, (state: ProductState) => ({
    ...state,
    loading: true,
    error: null,
  })),
  on(ProductActions.updateProductSuccess, (state: ProductState, { product }: { product: Product }) => ({
    ...state,
    products: state.products.map((p: Product) => (p.id === product.id ? product : p)),
    selectedProduct: product,
    loading: false,
  })),
  on(ProductActions.updateProductFailure, (state: ProductState, { error }: { error: string }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Delete Product
  on(ProductActions.deleteProduct, (state: ProductState) => ({
    ...state,
    loading: true,
    error: null,
  })),
  on(ProductActions.deleteProductSuccess, (state: ProductState, { id }: { id: number }) => ({
    ...state,
    products: state.products.filter((p: Product) => p.id !== id),
    selectedProduct: state.selectedProduct?.id === id ? null : state.selectedProduct,
    loading: false,
  })),
  on(ProductActions.deleteProductFailure, (state: ProductState, { error }: { error: string }) => ({
    ...state,
    error,
    loading: false,
  })),
  
  // Clear Selection
  on(ProductActions.clearProductSelection, (state: ProductState) => ({
    ...state,
    selectedProduct: null,
  }))
);
