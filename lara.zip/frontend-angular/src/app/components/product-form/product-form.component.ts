import { Component, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Product } from '../../services/product.service';
import * as ProductActions from '../../store/product.actions';
import { selectLoadingState, selectErrorState, selectSelectedProduct } from '../../store/product.selectors';

@Component({
  selector: 'app-product-form',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule, RouterLink],
  templateUrl: './product-form.component.html',
  styleUrl: './product-form.component.css'
})
export class ProductFormComponent implements OnInit {
  form: FormGroup;
  loading$: Observable<boolean>;
  error$: Observable<string | null>;
  selectedProduct$: Observable<Product | null>;
  productId: number | null = null;

  constructor(
    private fb: FormBuilder,
    private store: Store,
    @Optional() private route: ActivatedRoute | null,
    @Optional() private router: Router | null
  ) {
    this.form = this.fb.group({
      name: ['', [Validators.required, Validators.maxLength(255)]],
      description: [''],
      price: ['', [Validators.required, Validators.min(0)]],
      quantity: ['', [Validators.required, Validators.min(0)]],
    });

    this.loading$ = this.store.select(selectLoadingState);
    this.error$ = this.store.select(selectErrorState);
    this.selectedProduct$ = this.store.select(selectSelectedProduct);
  }

  ngOnInit(): void {
    if (this.route) {
      this.route.params.subscribe(params => {
        if (params['id']) {
          this.productId = params['id'];
          this.selectedProduct$.subscribe(product => {
            if (product) {
              this.form.patchValue({
                name: product.name,
                description: product.description || '',
                price: product.price.toString(),
                quantity: product.quantity.toString(),
              });
            }
          });
        } else {
          this.form.reset();
        }
      });
    } else {
      this.form.reset();
    }
  }

  onSubmit(): void {
    if (!this.form.valid) return;

    const data = this.form.value;

    if (this.productId) {
      this.store.dispatch(ProductActions.updateProduct({ id: this.productId, product: data }));
    } else {
      this.store.dispatch(ProductActions.createProduct({ product: data }));
    }

    this.loading$.subscribe(loading => {
      if (!loading) {
        this.error$.subscribe(error => {
          if (!error) {
            this.form.reset();
            if (this.router) {
              this.router.navigate(['/products']);
            }
          }
        });
      }
    });
  }
}
