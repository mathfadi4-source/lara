import { Component, OnInit, Optional } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { Product } from '../../services/product.service';
import * as ProductActions from '../../store/product.actions';
import { selectAllProducts, selectLoadingState, selectErrorState } from '../../store/product.selectors';

@Component({
  selector: 'app-product-list',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './product-list.component.html',
  styleUrl: './product-list.component.css'
})
export class ProductListComponent implements OnInit {
  products$: Observable<Product[]>;
  loading$: Observable<boolean>;
  error$: Observable<string | null>;

  constructor(
    private store: Store,
    @Optional() private router: Router | null
  ) {
    this.products$ = this.store.select(selectAllProducts);
    this.loading$ = this.store.select(selectLoadingState);
    this.error$ = this.store.select(selectErrorState);
  }

  ngOnInit(): void {
    this.store.dispatch(ProductActions.loadProducts());
  }

  onEdit(product: Product): void {
    if (this.router) {
      this.router.navigate(['/products/edit', product.id]);
    }
  }

  onDelete(id: number): void {
    if (!confirm('Are you sure?')) return;
    this.store.dispatch(ProductActions.deleteProduct({ id }));
  }
}
